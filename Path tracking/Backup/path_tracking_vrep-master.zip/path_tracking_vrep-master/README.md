More explanations available at
https://medium.com/@afakharany93/path-tracking-tutorial-for-pioneer-robot-in-vrep-acffcf76875b
